#pragma once

#include <ydb/core/tx/columnshard/columnshard_impl.h>

namespace NKikimr::NColumnShard {

class TBaseEvWriteTransactionOperator: public TTxController::ITransactionOperator {
private:
    using TBase = TTxController::ITransactionOperator;
    using TProposeResult = TTxController::TProposeResult;

protected:
    ui64 LockId = 0;

private:
    virtual bool DoParseImpl(TColumnShard& owner, const NKikimrTxColumnShard::TCommitWriteTxBody& commitTxBody) = 0;
    virtual TProposeResult DoStartProposeOnExecute(TColumnShard& owner, NTabletFlatExecutor::TTransactionContext& txc) override final {
        owner.OperationsManager->LinkTransaction(LockId, GetTxId(), txc);
        return TProposeResult();
    }
    virtual void DoStartProposeOnComplete(TColumnShard& /*owner*/, const TActorContext& /*ctx*/) override final {
    }
    virtual void DoFinishProposeOnExecute(TColumnShard& /*owner*/, NTabletFlatExecutor::TTransactionContext& /*txc*/) override final {
    }
    virtual void DoFinishProposeOnComplete(TColumnShard& /*owner*/, const TActorContext& /*ctx*/) override final {
    }
    virtual bool DoCheckAllowUpdate(const TFullTxInfo& currentTxInfo) const override final {
        return (currentTxInfo.Source == GetTxInfo().Source && currentTxInfo.Cookie == GetTxInfo().Cookie);
    }
    virtual bool DoParse(TColumnShard& owner, const TString& data) override final;
    virtual bool DoIsAsync() const override final {
        return false;
    }

    virtual void DoSendReply(TColumnShard& owner, const TActorContext& ctx) override {
        const auto& txInfo = GetTxInfo();
        std::unique_ptr<NActors::IEventBase> evResult;
        if (IsFail()) {
            evResult = NEvents::TDataEvents::TEvWriteResult::BuildError(owner.TabletID(), txInfo.GetTxId(),
                NKikimrDataEvents::TEvWriteResult::STATUS_INTERNAL_ERROR, GetProposeStartInfoVerified().GetStatusMessage());
        } else {
            evResult = NEvents::TDataEvents::TEvWriteResult::BuildPrepared(
                owner.TabletID(), txInfo.GetTxId(), owner.GetProgressTxController().BuildCoordinatorInfo(txInfo));
        }
        ctx.Send(txInfo.Source, evResult.release(), 0, txInfo.Cookie);
    }

public:
    TBaseEvWriteTransactionOperator(const TTxInfo& txInfo, const ui64 lockId)
        : TBase(txInfo)
        , LockId(lockId) {
    }

    virtual bool ProgressOnExecute(
        TColumnShard& owner, const NOlap::TSnapshot& version, NTabletFlatExecutor::TTransactionContext& txc) override {
        return owner.OperationsManager->CommitTransaction(owner, GetTxId(), txc, version);
    }

    virtual bool ProgressOnComplete(TColumnShard& owner, const TActorContext& ctx) override {
        auto result = NEvents::TDataEvents::TEvWriteResult::BuildCompleted(owner.TabletID(), GetTxId());
        ctx.Send(TxInfo.Source, result.release(), 0, TxInfo.Cookie);
        return true;
    }

    virtual bool ExecuteOnAbort(TColumnShard& owner, NTabletFlatExecutor::TTransactionContext& txc) override {
        return owner.OperationsManager->AbortTransaction(owner, GetTxId(), txc);
    }
    virtual bool CompleteOnAbort(TColumnShard& /*owner*/, const TActorContext& /*ctx*/) override {
        return true;
    }
};

class TEvWriteSimpleCommitTransactionOperator: public TBaseEvWriteTransactionOperator,
                                               public TMonitoringObjectsCounter<TEvWriteTransactionOperator> {
private:
    virtual bool DoParseImpl(TColumnShard& /*owner*/, const NKikimrTxColumnShard::TCommitWriteTxBody& /*commitTxBody*/) override {
        return true;
    }
    static inline auto Registrator = TFactory::TRegistrator<TEvWriteTransactionOperator>(NKikimrTxColumnShard::TX_KIND_COMMIT_WRITE);

public:
    virtual TString DoGetOpType() const override {
        return "EvWriteSimple";
    }
    virtual TString DoDebugString() const override {
        return "EV_WRITE_SIMPLE";
    }
};

class TEvWriteCommitSyncTransactionOperator: public TBaseEvWriteTransactionOperator {
private:
public:
    virtual std::unique_ptr<NTabletFlatExecutor::ITransaction> CreateReceiveResultAckTx(TColumnShard& owner, const ui64 recvTabletId) const = 0;
    virtual std::unique_ptr<NTabletFlatExecutor::ITransaction> CreateReceiveBrokenFlagTx(
        TColumnShard& owner, const ui64 sendTabletId, const bool broken) const = 0;
    virtual NKikimrTxColumnShard::TCommitWriteTxBody SerializeToProto() const = 0;
};

class TEvWriteCommitPrimaryTransactionOperator: public TBaseEvWriteTransactionOperator,
                                                public TMonitoringObjectsCounter<TEvWriteCommitPrimaryTransactionOperator> {
private:
    using TBase = TBaseEvWriteTransactionOperator;
    using TProposeResult = TTxController::TProposeResult;
    static inline auto Registrator = TFactory::TRegistrator<TEvWriteTransactionOperator>(NKikimrTxColumnShard::TX_KIND_COMMIT_WRITE_PRIMARY);

private:
    std::set<ui64> ReceivingShards;
    std::set<ui64> SendingShards;
    std::set<ui64> WaitShardsBrokenFlags;
    std::set<ui64> WaitShardsResultAck;
    std::optional<bool> TxBroken;

    virtual NKikimrTxColumnShard::TCommitWriteTxBody SerializeToProto() const override {
        NKikimrTxColumnShard::TCommitWriteTxBody result;
        auto& data = *result.MutablePrimaryTabletData();
        if (TxBroken) {
            data.SetTxBroken(*TxBroken);
        }
        for (auto&& i : ReceivingShards) {
            data.AddReceivingShards(i);
        }
        for (auto&& i : SendingShards) {
            data.AddSendingShards(i);
        }
        for (auto&& i : WaitShardsBrokenFlags) {
            data.AddWaitShardsBrokenFlags(i);
        }
        for (auto&& i : WaitShardsResultAck) {
            data.AddWaitShardsResultAck(i);
        }
        return result;
    }

    virtual bool DoParseImpl(TColumnShard& /*owner*/, const NKikimrTxColumnShard::TCommitWriteTxBody& commitTxBody) override {
        if (!commitTxBody.HasPrimaryTabletData()) {
            AFL_ERROR(NKikimrServices::TX_COLUMNSHARD)("event", "cannot read proto")("proto", commitTxBody.DebugString());
            return false;
        }
        auto& protoData = commitTxBody.GetPrimaryTabletData();
        for (auto&& i : protoData.GetReceivingShards()) {
            ReceivingShards.emplace(i);
        }
        for (auto&& i : protoData.GetSendingShards()) {
            SendingShards.emplace(i);
        }
        for (auto&& i : protoData.GetWaitShardsBrokenFlags()) {
            WaitShardsBrokenFlags.emplace(i);
        }
        for (auto&& i : protoData.GetWaitShardsResultAck()) {
            WaitShardsResultAck.emplace(i);
        }
        AFL_VERIFY(ReceivingShards.empty() == SendingShards.empty());
        if (protoData.HasTxBroken()) {
            TxBroken = protoData.GetTxBroken();
        }
        return true;
    }

private:
    virtual TString DoGetOpType() const override {
        return "EvWritePrimary";
    }
    virtual TString DoDebugString() const override {
        return "EV_WRITE_PRIMARY";
    }
    class TTxWriteReceivedBrokenFlag: public NDataSharing::TExtendedTransactionBase<TColumnShard> {
    private:
        using TBase = NDataSharing::TExtendedTransactionBase<TColumnShard>;
        const ui64 TxId;
        const ui64 TabletId;
        const bool BrokenFlag;

        virtual bool DoExecute(NTabletFlatExecutor::TTransactionContext& txc, const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitPrimaryTransactionOperator>(TxId);
            auto copy = *op;
            AFL_VERIFY(copy.WaitShardsBrokenFlags.erase(TabletId));
            copy.TxBroken = copy.TxBroken.value_or(false) || BrokenFlag;
            auto proto = copy.SerializeToProto();
            Self->GetProgressTxController().WriteTxOperatorStatus(copy);
        }
        virtual void DoComplete(const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitPrimaryTransactionOperator>(TxId);
            AFL_VERIFY(op->WaitShardsBrokenFlags.erase(TabletId));
            op->TxBroken = op->TxBroken.value_or(false) || BrokenFlag;
            SendBrokenFlagAck(*Self, TabletId);
            if (op->WaitShardsBrokenFlags.empty()) {
                SendResult(*Self);
            }
        }

    public:
        TTxWriteReceivedBrokenFlag(TColumnShard& owner, const ui64 tabletId, const bool broken)
            : TBase(owner)
            , TxId(txId)
            , TabletId(tabletId)
            , BrokenFlag(broken) {
        }
    };

    virtual std::unique_ptr<NTabletFlatExecutor::ITransaction> CreateReceiveBrokenFlagTx(
        TColumnShard& owner, const ui64 sendTabletId, const bool broken) const override {
        return std::make_unique<TTxWriteReceivedBrokenFlag>(owner, sendTabletId, broken);
    }

    class TTxWriteReceivedResultAck: public NDataSharing::TExtendedTransactionBase<TColumnShard> {
    private:
        using TBase = NDataSharing::TExtendedTransactionBase<TColumnShard>;
        const ui64 TxId;
        const ui64 TabletId;

        virtual bool DoExecute(NTabletFlatExecutor::TTransactionContext& txc, const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitPrimaryTransactionOperator>(TxId);
            auto copy = *op;
            AFL_VERIFY(copy.WaitShardsResultAck.erase(TabletId));
            auto proto = copy.SerializeToProto();
            Self->GetProgressTxController().WriteTxOperatorStatus(copy);
        }
        virtual void DoComplete(const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitPrimaryTransactionOperator>(TxId);
            AFL_VERIFY(op->WaitShardsResultAck.erase(TabletId));
            if (op->WaitShardsResultAck.empty()) {
                Self->Execute(new TTxProgressTx(Self));
            }
        }

    public:
        TTxWriteReceivedBrokenFlag(TColumnShard& owner, const ui64 tabletId, const bool broken)
            : TBase(owner)
            , TxId(txId)
            , TabletId(tabletId)
            , BrokenFlag(broken) {
        }
    };

    virtual std::unique_ptr<NTabletFlatExecutor::ITransaction> CreateReceiveResultAckTx(
        TColumnShard& owner, const ui64 recvTabletId) const override {
        return std::make_unique<TTxWriteReceivedResultAck>(owner, recvTabletId);
    }

    void SendBrokenFlagAck(TColumnShard& owner, const std::optional<ui64> tabletId = {}) {
        for (auto&& i : SendingShards) {
            if (!WaitShardsBrokenFlags.contains(i)) {
                if (tabletId && *tabletId != i) {
                    continue;
                }
                NActors::TActivationContext::AsActorContext().Send(MakePipePerNodeCacheID(false),
                    new TEvPipeCache::TEvForward(
                        new TEvTxProcessing::TEvReadSetAck(0, GetTxId(), owner.TabletID(), i, owner.TabletID()), i, true),
                    IEventHandle::FlagTrackDelivery, GetTxId());
            }
        }
    }

    void SendResult(TColumnShard& owner) {
        AFL_VERIFY(!!TxBroken);
        NKikimrTx::TReadSetData readSetData;
        readSetData.SetDecision(*TxBroken ? NKikimrTx::TReadSetData::DECISION_ABORT : NKikimrTx::TReadSetData::DECISION_COMMIT);
        for (auto&& i : ReceivingShards) {
            if (WaitShardsResultAck.contains(i)) {
                NActors::TActivationContext::AsActorContext().Send(MakePipePerNodeCacheID(false),
                    new TEvPipeCache::TEvForward(
                        new TEvTxProcessing::TEvReadSet(0, GetTxId(), owner.TabletID(), i, owner.TabletID(), readSetData.SerializeAsString()), i,
                        true),
                    IEventHandle::FlagTrackDelivery, GetTxId());
            }
        }
    }

    virtual void DoOnTabletInit(TColumnShard& owner) override {
        if (WaitShardsResultAck.empty()) {
            owner.Execute(new TTxProgressTx(&owner));
        } else if (WaitShardsBrokenFlags.empty()) {
            SendResult(owner);
        }
    }

    class TTxStartPreparation: public NDataSharing::TExtendedTransactionBase<TColumnShard> {
    private:
        using TBase = NDataSharing::TExtendedTransactionBase<TColumnShard>;
        const ui64 TxId;
        const ui64 LockId;

        virtual bool DoExecute(NTabletFlatExecutor::TTransactionContext& txc, const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitPrimaryTransactionOperator>(TxId);
            auto copy = *op;
            copy.TxBroken = Self->GetOperationsManager().GetLockVerified(LockId).GetBroken();
            AFL_VERIFY(copy.WaitShardsResultAck.erase(Self->TabletID()));
            auto proto = copy.SerializeToProto();
            Self->GetProgressTxController().WriteTxOperatorStatus(copy);
        }
        virtual void DoComplete(const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitPrimaryTransactionOperator>(TxId);
            op->TxBroken = Self->GetOperationsManager().GetLockVerified(LockId).GetBroken();
            AFL_VERIFY(op->WaitShardsResultAck.erase(Self->TabletID()));
        }

    public:
        TTxStartPreparation(TColumnShard& owner, const ui64 txId, const ui64 lockId)
            : TBase(owner)
            , TxId(txId)
            , LockId(lockId) {
        }
    };

    virtual std::unique_ptr<NTabletFlatExecutor::ITransaction> DoBuildTxPrepareForProgress(TColumnShard* owner) const override {
        if (WaitShardsResultAck.empty()) {
            return nullptr;
        }
        return std::make_unique<TTxStartPreparation>(owner, GetTxId(), owner->GetOperationsManager().GetLockForTxVerified(GetTxId()));
    }

public:
    using TBase::TBase;
    TEvWriteCommitPrimaryTransactionOperator(const TTxInfo& txInfo, const ui64 lockId, const std::set<ui64>& receivingShards, const std::set<ui64>& sendingShards)
        : TBase(txInfo, lockId)
        , ReceivingShards(receivingShards)
        , SendingShards(sendingShards) {
        WaitShardsBrokenFlags = SendingShards;
        WaitShardsResultAck = ReceivingShards;
    }
};

class TEvWriteCommitSecondaryTransactionOperator: public TBaseEvWriteTransactionOperator,
                                                  public TMonitoringObjectsCounter<TEvWriteCommitSecondaryTransactionOperator> {
private:
    using TBase = TBaseEvWriteTransactionOperator;
    using TProposeResult = TTxController::TProposeResult;
    static inline auto Registrator = TFactory::TRegistrator<TEvWriteTransactionOperator>(NKikimrTxColumnShard::TX_KIND_COMMIT_WRITE_SECONDARY);

private:
    ui64 ArbiterTabletId;
    bool NeedReceiveBroken = false;
    bool ReceiveAck = false;
    bool SelfBroken = false;
    std::optional<bool> TxBroken;

    virtual NKikimrTxColumnShard::TCommitWriteTxBody SerializeToProto() const override {
        NKikimrTxColumnShard::TCommitWriteTxBody result;
        auto& data = *result.MutableSecondaryTabletData();
        if (TxBroken) {
            data.SetTxBroken(*TxBroken);
        }
        data.SetSelfBroken(SelfBroken);
        data.SetNeedReceiveBroken(NeedReceiveBroken);
        data.SetReceiveAck(ReceiveAck);
        data.SetArbiterTabletId(ArbiterTabletId);
        return result;
    }

    virtual bool DoParseImpl(TColumnShard& /*owner*/, const NKikimrTxColumnShard::TCommitWriteTxBody& commitTxBody) override {
        if (!commitTxBody.HasSecondaryTabletData()) {
            AFL_ERROR(NKikimrServices::TX_COLUMNSHARD)("event", "cannot read proto")("proto", commitTxBody.DebugString());
            return false;
        }
        auto& protoData = commitTxBody.GetSecondaryTabletData();
        SelfBroken = protoData.SetSelfBroken();
        ArbiterTabletId = protoData.GetArbiterTabletId();
        NeedReceiveBroken = protoData.GetNeedReceiveBroken();
        ReceiveAck = protoData.GetReceiveAck();
        if (protoData.HasTxBroken()) {
            TxBroken = protoData.GetTxBroken();
        }
        return true;
    }

private:
    virtual TString DoGetOpType() const override {
        return "EvWriteSecondary";
    }
    virtual TString DoDebugString() const override {
        return "EV_WRITE_SECONDARY";
    }
    class TTxWriteReceivedAck: public NDataSharing::TExtendedTransactionBase<TColumnShard> {
    private:
        using TBase = NDataSharing::TExtendedTransactionBase<TColumnShard>;
        const ui64 TxId;

        virtual bool DoExecute(NTabletFlatExecutor::TTransactionContext& txc, const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitSecondaryTransactionOperator>(TxId);
            auto copy = *op;
            copy.ReceiveAck = true;
            auto proto = copy.SerializeToProto();
            Self->GetProgressTxController().WriteTxOperatorInfo(txc, TxId, proto.SerializeAsString());
        }
        virtual void DoComplete(const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitSecondaryTransactionOperator>(TxId);
            op->ReceiveAck = true;
            if (!NeedReceiveBroken) {
                Self->Execute(new TTxProgressTx(Self));
            }
        }

    public:
        TTxWriteReceivedAck(TColumnShard& owner)
            : TBase(owner)
            , TxId(txId) {
        }
    };

    virtual std::unique_ptr<NTabletFlatExecutor::ITransaction> CreateReceiveResultAckTx(
        TColumnShard& owner, const ui64 recvTabletId) const override {
        AFL_VERIFY(recvTabletId == ArbiterTabletId);
        return std::make_unique<TTxWriteReceivedAck>(owner);
    }

    class TTxWriteReceivedBrokenFlag: public NDataSharing::TExtendedTransactionBase<TColumnShard> {
    private:
        using TBase = NDataSharing::TExtendedTransactionBase<TColumnShard>;
        const ui64 TxId;
        const bool Broken;

        virtual bool DoExecute(NTabletFlatExecutor::TTransactionContext& txc, const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitSecondaryTransactionOperator>(TxId);
            auto copy = *op;
            copy.TxBroken = Broken;
            auto proto = copy.SerializeToProto();
            Self->GetProgressTxController().WriteTxOperatorInfo(TxId, proto.SerializeAsString());
            if (Broken) {
                Self->GetProgressTxController().ExecuteOnCancel(TxId, txc);
            }
        }
        virtual void DoComplete(const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitSecondaryTransactionOperator>(TxId);
            op->TxBroken = Broken;
            SendBrokenFlagAck(*Self);
            if (Broken) {
                Self->GetProgressTxController().CompleteOnCancel(TxId, ctx);
            } else {
                Self->Execute(new TTxProgressTx(Self));
            }
        }

    public:
        TTxWriteReceivedBrokenFlag(TColumnShard& owner, const ui64 tabletId, const bool broken)
            : TBase(owner)
            , TxId(txId)
            , TabletId(tabletId)
            , BrokenFlag(broken) {
        }
    };

    virtual std::unique_ptr<NTabletFlatExecutor::ITransaction> CreateReceiveBrokenFlagTx(
        TColumnShard& owner, const ui64 sendTabletId, const bool broken) const override {
        return std::make_unique<TTxWriteReceivedBrokenFlag>(owner, sendTabletId, broken);
    }

    void SendBrokenFlagAck(TColumnShard& owner, const std::optional<ui64> tabletId = {}) {
        NActors::TActivationContext::AsActorContext().Send(MakePipePerNodeCacheID(false),
            new TEvPipeCache::TEvForward(
                new TEvTxProcessing::TEvReadSetAck(0, GetTxId(), owner.TabletID(), ArbiterTabletId, owner.TabletID()), ArbiterTabletId, true),
            IEventHandle::FlagTrackDelivery, GetTxId());
    }

    void SendResult(TColumnShard& owner) {
        AFL_VERIFY(!!TxBroken);
        NKikimrTx::TReadSetData readSetData;
        readSetData.SetDecision(SelfBroken ? NKikimrTx::TReadSetData::DECISION_ABORT : NKikimrTx::TReadSetData::DECISION_COMMIT);
        NActors::TActivationContext::AsActorContext().Send(MakePipePerNodeCacheID(false),
            new TEvPipeCache::TEvForward(new TEvTxProcessing::TEvReadSet(
                                             0, GetTxId(), owner.TabletID(), ArbiterTabletId, owner.TabletID(), readSetData.SerializeAsString()),
                ArbiterTabletId, true),
            IEventHandle::FlagTrackDelivery, GetTxId());
    }

    virtual void DoOnTabletInit(TColumnShard& owner) override {
        if (TxBroken || (ReceiveAck && !NeedReceiveBroken)) {
            owner.Execute(new TTxProgressTx(&owner));
        } else if (!ReceiveAck) {
            SendResult(owner);
        }
    }

    class TTxStartPreparation: public NDataSharing::TExtendedTransactionBase<TColumnShard> {
    private:
        using TBase = NDataSharing::TExtendedTransactionBase<TColumnShard>;
        const ui64 TxId;
        const ui64 LockId;

        virtual bool DoExecute(NTabletFlatExecutor::TTransactionContext& txc, const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitSecondaryTransactionOperator>(TxId);
            auto copy = *op;
            copy.SelfBroken = Self->GetOperationsManager().GetLockVerified(LockId).GetBroken();
            auto proto = copy.SerializeToProto();
            Self->GetProgressTxController().WriteTxOperatorStatus(copy);
        }
        virtual void DoComplete(const NActors::TActorContext& ctx) override {
            auto op = Self->GetProgressTxController().GetTxOperatorVerifiedAs<TEvWriteCommitSecondaryTransactionOperator>(TxId);
            op->SelfBroken = Self->GetOperationsManager().GetLockVerified(LockId).GetBroken();
            SendResult(*Self);
        }

    public:
        TTxStartPreparation(TColumnShard& owner, const ui64 txId, const ui64 lockId)
            : TBase(owner)
            , TxId(txId)
            , LockId(lockId) {
        }
    };

    virtual std::unique_ptr<NTabletFlatExecutor::ITransaction> DoBuildTxPrepareForProgress(TColumnShard* owner) const override {
        return std::make_unique<TTxStartPreparation>(owner, GetTxId(), owner->GetOperationsManager().GetLockForTxVerified(GetTxId()));
    }

public:
    using TBase::TBase;
    TEvWriteCommitSecondaryTransactionOperator(const TTxInfo& txInfo, const ui64 lockId, const ui64 arbiterTabletId, const bool needReceiveBroken)
        : TBase(txInfo, lockId)
        , ArbiterTabletId(arbiterTabletId)
        , NeedReceiveBroken(needReceiveBroken) {
    }
};

}   // namespace NKikimr::NColumnShard
